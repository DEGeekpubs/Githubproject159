rootProject.name = "sentry-buildSrc"
