package io.sentry.android.core

import android.app.Application

class ApplicationStub : Application()
