package io.sentry.android.core

import io.sentry.hints.Cached

class CachedEvent : Cached
