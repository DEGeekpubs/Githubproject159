package io.sentry.android.core

import io.sentry.hints.ApplyScopeData
import io.sentry.hints.Cached

class CustomCachedApplyScopeDataHint : Cached, ApplyScopeData
