Building this module outputs:

1. sentry-compose-android
2. sentry-compose-desktop
3. sentry-compose


First two (Android and Desktop) depend on `sentry-compose`.
